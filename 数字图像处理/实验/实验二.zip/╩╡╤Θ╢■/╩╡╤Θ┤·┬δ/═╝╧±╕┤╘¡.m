clear();
src = imread('E:\����\����\������\����ͼ����\ʵ��\ʵ��ͼƬ\ͼƬ\sample6.bmp');
subplot(1,3,1);
imshow(uint8(src));
title('ԭͼ');
%src = map2gray(src);
[r, c] = size(src);

H = zeros(r, c);
k = 0.00001;
for row = 1:r
    for column = 1:c
        H(row, column) = exp(-k*(( row-r/2)^2+( column -c/2)^2)^(5/6));
    end
end

f = fftshift(fft2(double(src)));
f = f./H;
f = ifft2(ifftshift(f));
f = uint8(real(f));
subplot(1,3,2);
imshow(f);
title('���˲�');

H = zeros(r, c);
k = 0.0001;
for row = 1:r
    for column = 1:c
        H(row, column) = exp(-k*(( row-r/2)^2+( column -c/2)^2)^(5/6));
    end
end
spectrum = H.^2;
f = fftshift(fft2(double(src)));
HW = H./(spectrum + 0.0001);
f = f.*(HW);
f = ifft2(ifftshift(f));
f = uint8(real(f));
subplot(1,3,3);
imshow(f);
title('ά���˲�');


