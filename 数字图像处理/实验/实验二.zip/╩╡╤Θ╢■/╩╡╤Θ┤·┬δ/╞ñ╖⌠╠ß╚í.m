clear();
src = imread('E:\����\����\������\����ͼ����\ʵ��\ʵ��ͼƬ\ͼƬ\sample7-1.bmp');
subplot(2,2,1);
imshow(uint8(src));
title('ԭͼ1');

[r, c, d] = size(src);
src=double(src);
ar = src(10,10,1);
ag = src(10,10,2);
ab = src(10,10,3);

w=0.2549 * 3 * 255;
Y=zeros(r,c,d);
for i=1:r
    for j=1:c
        fr=src(i,j,1);
        fg=src(i,j,2);
        fb=src(i,j,3);
        if(sqrt((fr-ar).^2+(fg-ag).^2+(fb-ab).^2)<w/2)
            Y(i,j,1) = 0.5 * 255;
            Y(i,j,2) = 0.5 * 255;
            Y(i,j,3) = 0.5 * 255;
        else
            Y(i,j,1)=src(i,j,1);
            Y(i,j,2)=src(i,j,2);
            Y(i,j,3)=src(i,j,3);
        end
    end
end

subplot(2,2,2);
imshow(uint8(Y));
title('ȥ����');

src = imread('E:\����\����\������\����ͼ����\ʵ��\ʵ��ͼƬ\ͼƬ\sample7-1.bmp');
subplot(2,2,1);
imshow(uint8(src));
title('ԭͼ1');

[r, c, d] = size(src);
src=double(src);
ar = src(10,10,1);
ag = src(10,10,2);
ab = src(10,10,3);

w=0.2549 * 3 * 255;
Y=zeros(r,c,d);
for i=1:r
    for j=1:c
        fr=src(i,j,1);
        fg=src(i,j,2);
        fb=src(i,j,3);
        if(sqrt((fr-ar).^2+(fg-ag).^2+(fb-ab).^2)<w/2)
            Y(i,j,1) = 0.5 * 255;
            Y(i,j,2) = 0.5 * 255;
            Y(i,j,3) = 0.5 * 255;
        else
            Y(i,j,1)=src(i,j,1);
            Y(i,j,2)=src(i,j,2);
            Y(i,j,3)=src(i,j,3);
        end
    end
end

subplot(2,2,2);
imshow(uint8(Y));
title('ȥ����');

src = imread('E:\����\����\������\����ͼ����\ʵ��\ʵ��ͼƬ\ͼƬ\sample7-1.bmp');
subplot(2,2,1);
imshow(uint8(src));
title('ԭͼ1');

[r, c, d] = size(src);
src=double(src);
ar = src(10,10,1);
ag = src(10,10,2);
ab = src(10,10,3);

w=0.2549 * 3 * 255;
Y=zeros(r,c,d);
for i=1:r
    for j=1:c
        fr=src(i,j,1);
        fg=src(i,j,2);
        fb=src(i,j,3);
        if(sqrt((fr-ar).^2+(fg-ag).^2+(fb-ab).^2)<w/2)
            Y(i,j,1) = 0.5 * 255;
            Y(i,j,2) = 0.5 * 255;
            Y(i,j,3) = 0.5 * 255;
        else
            Y(i,j,1)=src(i,j,1);
            Y(i,j,2)=src(i,j,2);
            Y(i,j,3)=src(i,j,3);
        end
    end
end

subplot(2,2,2);
imshow(uint8(Y));
title('ȥ����');

src = imread('E:\����\����\������\����ͼ����\ʵ��\ʵ��ͼƬ\ͼƬ\sample7-2.bmp');
subplot(2,2,3);
imshow(uint8(src));
title('ԭͼ2');

[r, c, d] = size(src);
src=double(src);
ar = src(80,120,1);
ag = src(80,120,2);
ab = src(80,120,3);

w=0.2549 * 3 * 255;
Y=zeros(r,c,d);
for i=1:r
    for j=1:c
        fr=src(i,j,1);
        fg=src(i,j,2);
        fb=src(i,j,3);
        if(sqrt((fr-ar).^2+(fg-ag).^2+(fb-ab).^2)<w/2)
            Y(i,j,1)=src(i,j,1);
            Y(i,j,2)=src(i,j,2);
            Y(i,j,3)=src(i,j,3);
        else
            Y(i,j,1) = 0.5 * 255;
            Y(i,j,2) = 0.5 * 255;
            Y(i,j,3) = 0.5 * 255;
        end
    end
end

subplot(2,2,4);
imshow(uint8(Y));
title('��Ƥ��');